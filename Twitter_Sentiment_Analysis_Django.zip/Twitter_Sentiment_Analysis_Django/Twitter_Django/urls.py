from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$',views.index,name='index'),
    url(r'^Topic.html$',views.topic,name='topic'),
    url(r'^Result.html$',views.result,name='result'),

]