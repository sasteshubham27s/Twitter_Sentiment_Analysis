#Create object of Accesspoint class
#call corresponding function
import Twitter_Django.utils.AccessPoint

Ac