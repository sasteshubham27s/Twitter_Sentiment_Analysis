"""
ASGI config for Twitter_Sentiment_Analysis_Django project.

It exposes the ASGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/3.0/howto/deployment/asgi/
"""

import os

from django.core.asgi import get_asgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'Twitter_Sentiment_Analysis_Django.settings')

application = get_asgi_application()
